====================================
🚀 Xiaomi Push Fix Tool v1.1
====================================
Restore reliable notifications on Xiaomi China ROM devices
✔ No Root Required
✔ Works with HyperOS / MIUI China ROM
✔ Supports WhatsApp, Telegram, Outlook

A lightweight Windows utility package designed to improve
push notification reliability on Xiaomi devices running
China ROM / HyperOS / MIUI, especially in scenarios where
background apps are aggressively restricted.

Package contents expected in this release:
  - pushfix-tool-v1.1.exe
  - adb.exe
  - AdbWinApi.dll
  - AdbWinUsbApi.dll

What this tool does:
  - Disables aggressive idle behavior that may delay push
    notifications
  - Adjusts background execution policies
  - Helps restore more reliable notification delivery
  - Provides a practical ADB-based workflow without root

Recommended usage:
  1. Extract all files into the same folder
  2. Connect the phone via USB
  3. Enable Developer Options and USB Debugging
  4. Run pushfix-tool-v1.1.exe as Administrator
  5. Approve the USB debugging prompt on the phone
  6. Follow the on-screen menu

Important notes:
  - Run the tool as Administrator.
  - Some settings may need to be re-applied after reboot
  - Battery consumption may slightly increase
  - This tool is intended for advanced users
  - Use at your own discretion

Author:
  kaantellioglu

Project:
  https://github.com/kaantellioglu/xiaomi17-pro-max-push-fix-tool

Release branding:
  Built and packaged by kaantellioglu
  For Xiaomi notification troubleshooting and push recovery

============================================================
